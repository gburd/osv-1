/*
 * Copyright (C) 2026 Greg Burd
 *
 * This work is open source software, licensed under the terms of the
 * BSD license as described in the LICENSE file in the top-level directory.
 */

#ifdef LOCKPROF

#include <osv/lockprof.hh>
#include <osv/sched.hh>
#include <osv/debug.hh>
#include <osv/clock.hh>

namespace lockprof {

counter counters[SITE_MAX];

const char *site_name(int s)
{
    switch (s) {
    case SITE_REGISTRY_SHARD: return "registry_shard";
    case SITE_VMAS_WRITE:     return "vmas_write";
    case SITE_VMAS_READ:      return "vmas_read";
    case SITE_PAGE_RANGES:    return "page_ranges";
    default:                  return "?";
    }
}

static void dump_once()
{
    uint64_t total_wait = 0;
    for (int i = 0; i < SITE_MAX; i++) {
        total_wait += counters[i].wait_ns.load(std::memory_order_relaxed);
    }
    debugff("[LOCKPROF] total_blocked_wait_ns=%lu\n", total_wait);
    for (int i = 0; i < SITE_MAX; i++) {
        uint64_t w = counters[i].wait_ns.load(std::memory_order_relaxed);
        uint64_t c = counters[i].calls.load(std::memory_order_relaxed);
        uint64_t b = counters[i].waits.load(std::memory_order_relaxed);
        unsigned pct = total_wait ? (unsigned)((w * 100) / total_wait) : 0;
        debugff("[LOCKPROF]   %-16s calls=%lu blocked=%lu wait_ns=%lu (%u%%)\n",
                site_name(i), c, b, w, pct);
    }
}

void start_dumper()
{
    auto t = sched::thread::make([] {
        using namespace osv::clock::literals;
        while (true) {
            sched::timer tm(*sched::thread::current());
            tm.set(5_s);
            sched::thread::wait_until([&] { return tm.expired(); });
            dump_once();
        }
    });
    t->set_name("lockprof");
    t->start();
    // leak the thread object on purpose: it runs for the life of the image
}

} // namespace lockprof

#endif // LOCKPROF
