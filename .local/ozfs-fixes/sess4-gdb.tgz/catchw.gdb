set pagination off
set confirm off
target remote :1234
source /b/scripts/loader.py
osv syms
break abort
commands
  echo \n===== ABORT CAUGHT =====\n
  bt
  echo \n=== all-thread bt ===\n
  thread apply all bt
  echo \n===== END =====\n
end
continue
