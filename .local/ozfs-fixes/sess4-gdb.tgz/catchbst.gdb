set pagination off
set confirm off
set height 0
target remote :1234
break __assert_fail
commands
  echo \n===== ASSERT CAUGHT =====\n
  info registers
  echo \n===== RAW BT =====\n
  bt 40
  echo \n===== STACK DWORDS =====\n
  x/64gx $rsp
  echo \n===== END-ASSERT =====\n
end
continue
