set pagination off
set confirm off
target remote :1234
info registers rip
echo \n=== BT CPU0 ===\n
bt 30
echo \n=== END ===\n
detach
quit
