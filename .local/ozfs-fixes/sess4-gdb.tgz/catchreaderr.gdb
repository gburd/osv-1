set pagination off
set confirm off
connect
add-symbol-file /b/build/release.x64/libsolaris.so 0x100000000000
# dbuf_read_done: catch the i/o error branch (buf==NULL)
break dbuf.c:1396
commands
  silent
  printf "DBUFREADERR db=%p blkid=%lld level=%d zio_err=%d\n", db, db->db_blkid, db->db_level, (zio ? zio->io_error : -1)
  if zio != 0
    printf "  zio type=%d off=0x%llx size=0x%llx flags=0x%llx stage=0x%x\n", zio->io_type, zio->io_offset, zio->io_size, zio->io_flags, zio->io_stage
  end
  continue
end
continue
