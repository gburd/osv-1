set pagination off
set confirm off
connect
# halt the guest so osv syms can walk module list safely
interrupt
# load module symbols; ignore failure
python
try:
    gdb.execute("osv syms")
except Exception as e:
    gdb.write("osv-syms-failed: %s\n" % e)
end
break abort
break osv::handle_mmap_fault
break mmu::vm_sigsegv
commands
  printf "\n===== CAUGHT =====\n"
  bt
  printf "\n===== END =====\n"
end
continue
