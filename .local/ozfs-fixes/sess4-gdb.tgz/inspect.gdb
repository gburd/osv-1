set pagination off
set confirm off
target remote :1234
source /b/scripts/loader.py
osv syms
echo \n=== REGS ===\n
info registers rip rsp rbp rdi rsi rdx rcx rax cr2
echo \n=== BT ===\n
bt
echo \n=== THREAD ===\n
osv thread
detach
quit
