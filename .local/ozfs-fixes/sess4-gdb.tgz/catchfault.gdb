set pagination off
set confirm off
set height 0
target remote :1234
break osv::handle_mmap_fault
commands
  echo \n===== MMAP FAULT CAUGHT =====\n
  info registers rip rsp rbp rdi rsi rdx rcx rax rbx r12 r13 r14 r15
  echo \n=== BT ===\n
  bt 30
  echo \n=== [rdi] as dbuf candidate: dump 64 qwords from rdi ===\n
  x/64gx $rdi
  echo \n=== [rsi] dump 32 qwords ===\n
  x/32gx $rsi
  echo \n===== END-FAULT =====\n
end
continue
