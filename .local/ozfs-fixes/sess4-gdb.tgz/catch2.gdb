set pagination off
set confirm off
connect
osv syms
break abort
break osv::handle_mmap_fault
commands
  printf "\n===== CAUGHT FAULT =====\n"
  bt
  printf "\n===== END BT =====\n"
end
continue
