# gdb script: attach to running OSv guest, load module symbols, catch abort.
set pagination off
set confirm off
target remote :1234
source /b/scripts/loader.py
osv syms
# abort() is where OSv lands after an assertion/SIGSEGV-to-app-with-no-handler
break abort
# also catch the mmu fault handler that aborts the guest
break osv::handle_mmap_fault
commands
  echo \n===== CAUGHT FAULT =====\n
  bt
  echo \n===== THREAD =====\n
  osv thread
  echo \n===== REGS =====\n
  info registers rip rsp rbp rdi rsi rdx
  echo \n===== END =====\n
end
continue
