set pagination off
set confirm off
set height 0
target remote :1234
echo \n===== INTERRUPTED: all-thread backtrace =====\n
thread apply all bt 20
echo \n===== END =====\n
