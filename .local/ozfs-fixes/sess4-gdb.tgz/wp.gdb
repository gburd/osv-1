set pagination off
set confirm off
target remote :1234
watch *(unsigned long*)0x40b35a60
commands
  printf "\n===== RING WATCHPOINT FIRED =====\n"
  info registers rip rsp rbp rdi rsi rdx rcx rax cr2 cr3
  bt
  x/6i $rip
  printf "===== END WP =====\n"
end
continue
