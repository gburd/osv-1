set pagination off
set confirm off
connect
add-symbol-file /b/build/release.x64/libsolaris.so 0x100000000000
break osv::handle_mmap_fault
commands
  printf "\n===== CAUGHT FAULT =====\n"
  bt
  printf "\n===== dbuf state =====\n"
  frame 5
  p db
  p db->db_state
  p db->db_buf
  p db->db_level
  p db->db_blkid
  p (long)db->db.db_object
  p db->db_holds.rc_count
  printf "\n===== END =====\n"
end
continue
