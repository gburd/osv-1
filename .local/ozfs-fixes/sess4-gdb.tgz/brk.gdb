set pagination off
set confirm off
target remote :1234
break abort
break __assert_fail
continue
