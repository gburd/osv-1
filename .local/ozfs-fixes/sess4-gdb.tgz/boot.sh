#!/bin/bash
# boot-until-ready: reap, boot serve.sh, wait for PG ready; retry on mount-hang.
# args: SMP MEM LOGFILE MAXTRIES
SMP="${1:-4}"; MEM="${2:-32G}"; LOG="${3:-/tmp/pg.log}"; MAX="${4:-4}"
for try in $(seq "$MAX"); do
  pkill -9 -f qemu-system 2>/dev/null; sleep 6
  # wait for any lingering process to drop the image lock
  while [ "$(ps aux | grep [q]emu-system | grep -v defunct | wc -l)" != "0" ]; do sleep 2; done
  ( timeout 3000 bash /b/.local/ozfs-fixes/serve.sh "$SMP" "$MEM" >"$LOG" 2>&1 ) &
  # wait up to 60s for ready
  for w in $(seq 30); do
    sleep 2
    if grep -qa "ready to accept" "$LOG"; then echo "READY (try $try)"; exit 0; fi
    if grep -qa "Aborted" "$LOG"; then echo "CRASH-AT-BOOT (try $try)"; break; fi
  done
  echo "boot try $try did not reach ready; reaping + retry"
done
echo "FAILED to boot after $MAX tries"
exit 1
