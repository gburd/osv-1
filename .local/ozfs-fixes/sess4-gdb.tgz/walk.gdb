set pagination off
set confirm off
target remote :1234
set $va=0x600100d814c0
set $pml4=$cr3 & ~0xfff
set $e4=*(unsigned long*)(0x400000000000+$pml4+(($va>>39)&0x1ff)*8)
printf "pml4[%d]=0x%lx\n",($va>>39)&0x1ff,$e4
set $e3=*(unsigned long*)(0x400000000000+($e4&0xffffff000)+(($va>>30)&0x1ff)*8)
printf "pdpt[%d]=0x%lx\n",($va>>30)&0x1ff,$e3
set $e2=*(unsigned long*)(0x400000000000+($e3&0xffffff000)+(($va>>21)&0x1ff)*8)
printf "pd[%d]=0x%lx\n",($va>>21)&0x1ff,$e2
detach
