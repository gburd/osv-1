set pagination off
set confirm off
connect
add-symbol-file /b/build/release.x64/libsolaris.so 0x100000000000
break zio.c:5241
commands
  silent
  printf "CKSUMERR type=%d dev_off=0x%llx size=0x%llx flags=0x%llx err=%d\n", zio->io_type, zio->io_offset, zio->io_size, zio->io_flags, error
  continue
end
continue
