#!/bin/bash
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"

qemu-system-x86_64 -cpu max -m 8G -smp 2 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 \
  -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 \
  -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  -s -S > /tmp/pbc.log 2>&1 &
QPID=$!
sleep 2

timeout 220 gdb -q -batch \
  -ex "set pagination off" -ex "set confirm off" -ex "set height 0" -ex "set width 0" \
  -ex "target remote localhost:1234" \
  -ex "tbreak osv::handle_mmap_fault" \
  -ex "continue" \
  -ex "printf \"FAULTADDR=0x%lx SIG=%d\n\", (unsigned long)\$rdi, (int)\$rsi" \
  -ex "bt" \
  -ex "frame 4" \
  -ex "info symbol \$pc" \
  -ex "x/3i \$pc" \
  /b/build/last/loader.elf > /tmp/gdb-out.txt 2>&1
kill -9 $QPID 2>/dev/null
echo "===== GDB OUTPUT ====="
grep -vE "Missing auto-load|auto-load python" /tmp/gdb-out.txt | head -70
