#!/bin/bash
# Phase B on the EC2 HOST (not container) with tap0 networking so an external
# instance can reach the guest's PostgreSQL cross-instance.  Artifacts are the
# same bind-mounted build tree ($HOME/osv/build).  Run setup-tap-net.sh first.
set -u
OSV=$HOME/osv
IMG=$OSV/build/last/usr.img
KERNEL=$OSV/build/last/loader.elf
DATADISK=/mnt/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
TAP=tap0
GUEST_IP=192.168.100.2
GW=192.168.100.1

# static IP on eth0 (tap has no DHCP server); import pgdata; run postgres.
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs --ip=eth0,$GUEST_IP,255.255.255.0 --defaultgw=$GW $INIT"

echo "== Phase B (host, tap0) : guest PG at $GUEST_IP:5432, reachable via host ENI DNAT =="
exec sudo qemu-system-x86_64 -enable-kvm -cpu host -m 32G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 \
  -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 \
  -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev tap,id=un0,ifname=$TAP,script=no,downscript=no \
  -device virtio-net-pci,netdev=un0,mac=52:54:00:12:34:56 \
  -s
