#!/bin/bash
echo "=== epoll.cc kernel_heap_scope usage pattern ==="
sed -n '25,90p' /b/core/epoll.cc | grep -n "fork_arena\|kernel_heap_scope\|EPOLL_KH\|CONF_fork\|#if\|#endif\|#include"
echo "--- fork_arena.hh kernel_heap_scope class ---"
grep -n "kernel_heap_scope\|class\|struct\|CONF_fork" /b/include/osv/fork_arena.hh | head -20
echo "--- kernel_config_fork header name ---"
ls /b/include/osv/kernel_config_fork.h 2>/dev/null || find /b -name "kernel_config_fork*" 2>/dev/null | head
