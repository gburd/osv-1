#!/bin/bash
echo "=== EC2 libc/pthread.cc lines 270-320 ==="
sed -n '270,320p' /b/.local/../pthread_placeholder 2>/dev/null
sed -n '270,320p' /b/libc/pthread.cc
