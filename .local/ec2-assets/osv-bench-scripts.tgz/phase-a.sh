#!/bin/bash
# Phase A: create the ZFS pgdata pool on the NVMe-backed vblk1 and initdb PG onto /data.
# Runs INSIDE the fedora build container (qemu + kvm). Boots the combined OSv image.
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin

# The ZFS root (pool 'osv' on vblk0.1) mounts via --rootfs=zfs so the PG binaries
# on it are reachable.  We additionally create pool 'pgdata' on NVMe-backed vblk1.
# ; = sequential (each program waits for the previous to exit).
INIT="/zpool.so create -f -o ashift=12 -O compression=lz4 -O atime=off -O recordsize=8k -m /data pgdata /dev/vblk1"
INIT="$INIT ; $PGBIN/initdb -D /data -U postgres --no-locale -E UTF8 -A trust"
INIT="$INIT ; /zpool.so export pgdata"

APPEND="--rootfs=zfs $INIT"

echo "== Phase A boot: create pgdata pool + initdb =="
echo "APPEND=$APPEND"
timeout 300 qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" \
  -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 \
  -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 \
  -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  2>&1
echo "== Phase A qemu exit rc=$? =="
