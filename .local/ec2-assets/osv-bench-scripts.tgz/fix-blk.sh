#!/bin/bash
# Fix: virtio-blk request objects freed cross-AS by the completion thread.
# A forked PostgreSQL backend issues a ZFS read/write; make_request() does
# `new blk_req(bio)` on the backend's thread, so the request lands in that
# backend's COW fork arena.  The single blk completion thread (req_done ->
# drain_queue, running in AS0) then `delete req` frees it -> fork_arena::free()
# reads a DIVERGENT arena chunk header (magic mismatch) -> assert/abort.  Same
# rule/fix as the virtio-net TX net_req: allocate the request on the identity
# kernel heap so `delete` frees it correctly from any address space.
set -e
python3 - <<'PY'
p="/b/drivers/virtio-blk.cc"
s=open(p).read()

# add fork_arena include (guarded) after the mmu.hh include
inc='#include <osv/mmu.hh>\n'
assert s.count(inc)>=1, ("mmu.hh include", s.count(inc))
add='#include <osv/mmu.hh>\n#include <osv/kernel_config_fork.h>\n#if CONF_fork\n#include <osv/fork_arena.hh>\n#endif\n'
s=s.replace(inc, add, 1)

# wrap the request allocation on the identity kernel heap
old="        auto* req = new blk_req(bio);\n"
assert s.count(old)==1, ("blk_req alloc", s.count(old))
new=('''#if CONF_fork
        // Freed cross-AS by the blk completion thread (req_done/drain_queue in
        // AS0); keep it on the identity kernel heap so free() works from any AS.
        blk_req* req;
        { fork_arena::kernel_heap_scope _blk_kh; req = new blk_req(bio); }
#else
        auto* req = new blk_req(bio);
#endif
''')
s=s.replace(old, new, 1)

open(p,"w").write(s)
print("patched drivers/virtio-blk.cc: blk_req -> identity kernel heap (#if CONF_fork)")
PY
echo "=== verify ==="
grep -n "fork_arena\|_blk_kh\|new blk_req" /b/drivers/virtio-blk.cc | head
