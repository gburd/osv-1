#!/bin/bash
set -u
bash /tmp/phase-a-seed.sh > /tmp/seed.log 2>&1
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=disabled pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"
nohup qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 -s > /tmp/pbbk.log 2>&1 &
echo $! > /tmp/qpidbk
for i in $(seq 1 90); do sleep 1; grep -q "ready to accept" /tmp/pbbk.log 2>/dev/null && break; done
