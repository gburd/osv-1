#!/bin/bash
# Seed the (already-created, empty) raidz "pgdata" pool: import, cpiod-receive
# the initdb cluster into /data, export. Runs inside osv-build.
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
SRC=/b/.local/pg18/data-init

INIT="/zpool.so import -f -N pgdata"
INIT="$INIT ; /zfs.so mount pgdata"
INIT="$INIT ; /tools/cpiod.so --prefix /data/ --port 10000"
INIT="$INIT ; /zpool.so export pgdata"
APPEND="--rootfs=zfs $INIT"

echo "== seed boot: import empty pool + cpiod-receive cluster =="
# pusher: sleep so guest boots, imports, mounts, and cpiod binds before we connect;
# retry the whole push on a reset (cpiod not yet ready).
(
  sleep 20
  for try in 1 2 3 4 5; do
    python3 /tmp/cpio_push.py "$SRC" 127.0.0.1 10000 2>&1 | sed "s/^/[push try$try] /"
    if [ "${PIPESTATUS[0]}" = 0 ]; then break; fi
    echo "[push] retry in 5s"; sleep 5
  done
) &
PUSH=$!

timeout 300 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk2,drive=hd2 -drive "file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk3,drive=hd3 -drive "file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk4,drive=hd4 -drive "file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk5,drive=hd5 -drive "file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk6,drive=hd6 -drive "file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native" \
  -netdev "user,id=un0,hostfwd=tcp:127.0.0.1:10000-:10000" -device virtio-net-pci,netdev=un0 \
  2>&1 | tee /tmp/seed.log
echo "== qemu exit rc=$? =="
wait $PUSH 2>/dev/null
