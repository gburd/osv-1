#!/bin/bash
echo "=== EC2 main.c check_root line 446 ==="
sed -n '446p' /b/.local/pg18/src/src/backend/main/main.c
echo "=== EC2 miscinit.c perm-check if ==="
grep -n 'st_mode & PG_MODE_MASK_GROUP' /b/.local/pg18/src/src/backend/utils/init/miscinit.c
