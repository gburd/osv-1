#!/bin/bash
# Durability proof: re-import the SAME pgdata pool (NO reseed) after a guest
# crash/reboot, run PG (which does crash recovery), and read back the data.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=disabled pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/pbreboot.log
nohup qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  -s > /tmp/pbreboot.log 2>&1 &
echo $! > /tmp/qpidreboot
for i in $(seq 1 120); do sleep 1; grep -q "ready to accept" /tmp/pbreboot.log 2>/dev/null && { echo "READY (reimport) at ${i}s"; break; }; done
grep -q "ready to accept" /tmp/pbreboot.log || { echo NOT_READY; tail -12 /tmp/pbreboot.log; }
