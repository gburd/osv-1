#!/bin/bash
# Fix: skip atfork handlers whose code belongs to an ELF object that has since
# been UNLOADED.  On OSv the atfork_handlers list is process-global (kernel
# BSS), so apps run via osv::run() before the main app (e.g. zpool.so/zfs.so in
# the boot cmdline, or import_extra_zfs_pools) register handlers via
# __register_atfork and then EXIT -- their code is unmapped, but their handler
# entries persist.  When the main app (PostgreSQL) then fork()s,
# __osv_run_atfork_prepare() would call those dead pointers -> instruction-fetch
# SIGSEGV.  Guard every call with elf::object_containing_addr(): a handler in an
# unloaded object returns null and is skipped.
set -e
python3 - <<'PY'
p="/b/libc/pthread.cc"
s=open(p).read()

# add elf.hh include (for object_containing_addr) next to fork_arena.hh
inc='#include <osv/fork_arena.hh>\n#include <osv/kernel_config_fork.h>\n'
assert s.count(inc)==1, ("inc anchor", s.count(inc))
s=s.replace(inc, inc+'#include <osv/elf.hh>\n', 1)

# add a helper just before __osv_run_atfork_prepare (after the ATFORK_KH macro block)
anchor='extern "C" void __osv_run_atfork_prepare()\n{'
assert s.count(anchor)==1, ("prepare anchor", s.count(anchor))
helper='''// A handler is safe to call only if its code still belongs to a loaded ELF
// object.  Apps run via osv::run() (zpool.so/zfs.so at boot) register atfork
// handlers and then exit, leaving dead entries in this process-global list.
static inline bool atfork_handler_live(void (*fn)(void))
{
    if (!fn) return false;
    return elf::get_program()->object_containing_addr(
               reinterpret_cast<const void*>(fn)) != nullptr;
}

'''
s=s.replace(anchor, helper+anchor, 1)

# guard the three call sites
s=s.replace("        if (it->prepare) it->prepare();",
            "        if (atfork_handler_live(it->prepare)) it->prepare();", 1)
s=s.replace("        if (h.parent) h.parent();",
            "        if (atfork_handler_live(h.parent)) h.parent();", 1)
s=s.replace("        if (h.child) h.child();",
            "        if (atfork_handler_live(h.child)) h.child();", 1)

open(p,"w").write(s)
print("patched __osv_run_atfork_* to skip handlers in unloaded objects")
PY
echo "=== verify ==="
grep -n "atfork_handler_live\|object_containing_addr\|elf.hh" /b/libc/pthread.cc
