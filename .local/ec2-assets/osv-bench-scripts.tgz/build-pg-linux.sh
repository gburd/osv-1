#!/bin/bash
set -e
SRC=$HOME/pg18-linux/src
PREFIX=$HOME/pg18-linux/install
BUILD=$HOME/pg18-linux/obj
# clean prior build/install (idempotent) without a destructive one-liner
[ -d "$BUILD" ] && find "$BUILD" -mindepth 1 -delete 2>/dev/null || true
[ -d "$PREFIX" ] && find "$PREFIX" -mindepth 1 -delete 2>/dev/null || true
mkdir -p "$BUILD" "$PREFIX"; cd "$BUILD"
# stock glibc gcc; same feature flags as the OSv build (only libc differs).
# Do NOT force WAIT_USE_SELF_PIPE on Linux (glibc epoll is the stock path).
"$SRC/configure" --prefix="$PREFIX" \
  --without-icu --without-zlib --without-readline \
  --without-libxml --without-lz4 --without-zstd \
  CFLAGS="-O2 -g" 2>&1 | tail -3
make -s -j"$(nproc)" 2>&1 | tail -4
make -s install 2>&1 | tail -2
echo "=== PG_LINUX_BUILD_DONE ==="
file "$PREFIX/bin/postgres"; "$PREFIX/bin/postgres" --version
