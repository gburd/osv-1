#!/bin/bash
# Add .note.osv-mlock to the postgres binary so OSv populates (mlocks) its ELF
# segments at load -> PG .text is resident, not demand-paged from ZFS, so the
# atfork-prepare instruction-fetch during fork() cannot fault.
set -e
B=/b/.local/pg18/install/bin/postgres
printf '\0\0\0\0\0\0\0\0\0\0\0\0' > /tmp/mlocknote.bin   # .long 0,0,0
objcopy --add-section .note.osv-mlock=/tmp/mlocknote.bin \
        --set-section-flags .note.osv-mlock=alloc,readonly \
        "$B" "$B.mlock"
mv "$B.mlock" "$B"
echo "=== sections ==="
readelf -S "$B" | grep -A1 osv-mlock || readelf -S "$B" | grep mlock
file "$B"
