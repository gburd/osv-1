#!/bin/bash
echo "=== register_atfork + includes ==="
sed -n '1,40p' /b/libc/pthread.cc | grep -n "include\|kernel_heap_scope\|fork_arena\|CONF_fork" 
echo "--- register_atfork body ---"
sed -n '318,345p' /b/libc/pthread.cc
echo "--- does fork_arena header get included anywhere in pthread.cc? ---"
grep -n "fork_arena\|kernel_heap_scope\|CONF_fork\|kernel_config_fork" /b/libc/pthread.cc
echo "--- how other files use kernel_heap_scope (example) ---"
grep -n "kernel_heap_scope\|include.*fork_arena" /b/core/epoll.cc | head
