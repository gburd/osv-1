#!/bin/bash
# Boot PG on the raidz under gdb; reproduce the fork_arena assert with a big
# write; capture the faulting pointer + backtrace. HARD timeout on qemu.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=disabled pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data -c autovacuum=off -c max_parallel_workers_per_gather=0 -c max_parallel_workers=0"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/repro.log
timeout 240 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk2,drive=hd2 -drive "file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk3,drive=hd3 -drive "file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk4,drive=hd4 -drive "file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk5,drive=hd5 -drive "file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk6,drive=hd6 -drive "file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native" \
  -netdev "user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432" -device virtio-net-pci,netdev=un0 \
  -s > /tmp/repro.log 2>&1 &
QPID=$!
for i in $(seq 1 90); do sleep 1; grep -q "ready to accept" /tmp/repro.log 2>/dev/null && { echo "READY at ${i}s"; break; }; done
grep -q "ready to accept" /tmp/repro.log || { echo NOT_READY; tail -8 /tmp/repro.log; kill -9 $QPID 2>/dev/null; exit 1; }
# fire the big write in background, then watch for the assert
( $PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c \
  "drop table if exists big; create table big as select g x, repeat(chr(65+g%26),100) t from generate_series(1,200000) g; checkpoint; select count(*) from big;" 2>&1 | sed 's/^/[sql] /' ) &
# wait up to 60s for either assert or sql done
for i in $(seq 1 60); do
  sleep 1
  grep -q "Assertion failed" /tmp/repro.log && { echo "ASSERT HIT at ${i}s"; break; }
  grep -q "fork_arena" /tmp/repro.log && { echo "ARENA MSG at ${i}s"; break; }
done
echo "=== repro.log tail ==="; tail -30 /tmp/repro.log
kill -9 $QPID 2>/dev/null
pkill -9 -f qemu-system 2>/dev/null
echo DONE
