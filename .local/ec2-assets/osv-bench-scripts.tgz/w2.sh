#!/bin/bash
# WALL 2: reproduce the ZIL-replay SPL panic (sync=standard, kill-9 mid-txg,
# re-import) and catch the abd_alloc_linear VERIFY backtrace in gdb. HARD timeout.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
DRIVES="-device virtio-blk-pci,id=blk0,drive=hd0 -drive file=$IMG,if=none,id=hd0,cache=writeback,aio=threads \
 -device virtio-blk-pci,id=blk1,drive=hd1 -drive file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk2,drive=hd2 -drive file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk3,drive=hd3 -drive file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk4,drive=hd4 -drive file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk5,drive=hd5 -drive file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk6,drive=hd6 -drive file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native"
NET="-netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0"

# PHASE 1: sync=standard, write with fsync-heavy load, kill mid-txg (NO settle).
INIT1="/zpool.so import -f -N pgdata ; /zfs.so set sync=standard pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data -c autovacuum=off -c max_parallel_workers_per_gather=0"
rm -f /tmp/w2a.log
timeout 120 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "--rootfs=zfs $INIT1" $DRIVES $NET -s > /tmp/w2a.log 2>&1 &
Q1=$!
for i in $(seq 1 150); do sleep 1; grep -q "ready to accept" /tmp/w2a.log 2>/dev/null && { echo "P1 READY ${i}s"; break; }; done
grep -q "ready to accept" /tmp/w2a.log || { echo P1_NOTREADY; tail -6 /tmp/w2a.log|grep -vE "iPXE|SeaBIOS"; kill -9 $Q1; pkill -9 -f qemu-system; exit 1; }
# fsync-heavy: many small committed txns (each fsyncs WAL -> ZIL on SLOG)
( for n in $(seq 1 200); do $PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c "create table if not exists zt(id serial, t text); insert into zt(t) values (repeat('"'"'z'"'"',500));" >/dev/null 2>&1; done ) &
WPID=$!
sleep 6   # let ZIL fill the SLOG, then crash mid-activity (no checkpoint, no settle)
kill -9 $WPID 2>/dev/null
kill -9 $Q1 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo "== P1 killed mid-ZIL =="
sleep 3

# PHASE 2: re-import -> expect ZIL replay -> SPL panic. Catch it in gdb.
INIT2="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; /b/.local/pg18/install/bin/postgres -D /data -c autovacuum=off"
rm -f /tmp/w2b.log
timeout 120 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "--rootfs=zfs $INIT2" $DRIVES $NET -s > /tmp/w2b.log 2>&1 &
Q2=$!
sleep 8   # let import + ZIL replay run (panic happens fast on import)
echo "=== P2 import log ==="; grep -vE "iPXE|SeaBIOS|Press Ctrl|Booting from ROM" /tmp/w2b.log | tail -20
cd /b/build/last
timeout 60 gdb -q -batch -iex "set auto-load safe-path /" \
  -ex "set pagination off" -ex "set confirm off" \
  -ex "target remote localhost:1234" \
  -ex "osv syms" \
  -ex "bt 45" \
  -ex "detach" loader.elf 2>&1 | grep -vE "^  -drive|Missing auto-load|info auto-load" | grep -E "^#|abd_alloc|zil|lr_|VERIFY|replay|zvol|dmu" | head -50
kill -9 $Q2 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo DONE
