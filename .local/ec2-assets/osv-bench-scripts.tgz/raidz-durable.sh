#!/bin/bash
# Durability proof on the raidz: (1) boot PG, write a marker + checkpoint,
# capture write counter, kill -9 the guest; (2) reboot with the SAME raidz
# devices, PG does crash recovery, read the marker back. HARD timeouts.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
DRIVES="-device virtio-blk-pci,id=blk0,drive=hd0 -drive file=$IMG,if=none,id=hd0,cache=writeback,aio=threads \
 -device virtio-blk-pci,id=blk1,drive=hd1 -drive file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk2,drive=hd2 -drive file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk3,drive=hd3 -drive file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk4,drive=hd4 -drive file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk5,drive=hd5 -drive file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk6,drive=hd6 -drive file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native"
NET="-netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0"
# sync=STANDARD for the durability test so WAL fsync actually hits the SLOG/pool.
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=standard pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data -c autovacuum=off -c max_parallel_workers_per_gather=0 -c max_parallel_workers=0"
APPEND="--rootfs=zfs $INIT"

boot(){ # $1=logfile
  rm -f "$1"
  timeout 150 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
    -kernel "$KERNEL" -append "$APPEND" $DRIVES $NET -s > "$1" 2>&1 &
  echo $!
}
wait_ready(){ for i in $(seq 1 90); do sleep 1; grep -q "ready to accept" "$1" 2>/dev/null && { echo "READY ${i}s"; return 0; }; done; echo NOTREADY; tail -6 "$1"; return 1; }

echo "===== PHASE 1: write marker + checkpoint, then kill -9 ====="
Q1=$(boot /tmp/dur1.log); wait_ready /tmp/dur1.log || { kill -9 $Q1; exit 1; }
$PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c \
  "drop table if exists durx; create table durx(id int primary key, tag text); insert into durx values (1,'RAIDZ-DURABLE-MARKER'); checkpoint; select * from durx;" 2>&1
sync
echo "== settle 12s to let the ZFS txg containing durx sync to the pool =="
sleep 12
kill -9 $Q1 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo "== guest killed (simulated crash) =="
sleep 3

echo "===== PHASE 2: reboot, crash-recover, read marker back ====="
Q2=$(boot /tmp/dur2.log); wait_ready /tmp/dur2.log || { kill -9 $Q2; exit 1; }
echo "-- recovery lines --"; grep -E "recovery|redo|ready to accept" /tmp/dur2.log
echo "-- read marker after reboot --"
$PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c "select * from durx;" 2>&1
kill -9 $Q2 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo DONE
