#!/bin/bash
# OSv-KVM PG serve for the benchmark, run INSIDE the osv-net container (tap0).
# Guest PG reachable cross-instance via host DNAT 172.31.12.162:5432 -> 192.168.100.2.
# usage (inside container):  osv-kvm-serve.sh on|off   (hugepage-backed guest RAM)
set -u
HP="${1:-off}"
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
GUEST_IP=192.168.100.2
GW=192.168.100.1
# benchmark PG args (identical to Linux config; parallel query works per pg-parallel.txt)
PGARGS="-c listen_addresses=* -c shared_buffers=8GB -c effective_cache_size=24GB"
PGARGS="$PGARGS -c work_mem=32MB -c maintenance_work_mem=1GB -c max_connections=256"
PGARGS="$PGARGS -c max_wal_size=16GB -c min_wal_size=4GB -c checkpoint_timeout=15min"
PGARGS="$PGARGS -c checkpoint_completion_target=0.9 -c synchronous_commit=on"
PGARGS="$PGARGS -c max_parallel_workers=8 -c max_parallel_workers_per_gather=2 -c max_worker_processes=16"
PGARGS="$PGARGS -c effective_io_concurrency=200 -c random_page_cost=1.1 -c autovacuum=on"
PGARGS="$PGARGS -c unix_socket_directories="
# sync=standard = durable ZIL on the SLOG (matches Linux synchronous_commit=on)
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=standard pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data $PGARGS"
APPEND="--rootfs=zfs --ip=eth0,$GUEST_IP,255.255.255.0 --defaultgw=$GW $INIT"

MEMOPT=""
if [ "$HP" = "on" ]; then
  MEMOPT="-mem-path /dev/hugepages -mem-prealloc"
fi

DRIVES="-device virtio-blk-pci,id=blk0,drive=hd0 -drive file=$IMG,if=none,id=hd0,cache=writeback,aio=threads \
 -device virtio-blk-pci,id=blk1,drive=hd1 -drive file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk2,drive=hd2 -drive file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk3,drive=hd3 -drive file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk4,drive=hd4 -drive file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk5,drive=hd5 -drive file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk6,drive=hd6 -drive file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native"
NET="-netdev tap,id=un0,ifname=tap0,script=no,downscript=no -device virtio-net-pci,netdev=un0,mac=52:54:00:12:34:56"

rm -f /tmp/osv-kvm.log
echo "== OSv-KVM serve hp=$HP guest=$GUEST_IP:5432 =="
nohup qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot $MEMOPT \
  -kernel "$KERNEL" -append "$APPEND" $DRIVES $NET > /tmp/osv-kvm.log 2>&1 &
echo $! > /tmp/osv-kvm.qpid
for i in $(seq 1 120); do sleep 1; grep -q "ready to accept" /tmp/osv-kvm.log 2>/dev/null && { echo "READY ${i}s"; break; }; done
grep -q "ready to accept" /tmp/osv-kvm.log || { echo NOTREADY; tail -8 /tmp/osv-kvm.log | grep -vE "iPXE|SeaBIOS"; exit 1; }
echo "== OSv-KVM PG ready hp=$HP =="
