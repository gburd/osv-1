#!/bin/bash
set -u
bash /tmp/phase-a-seed.sh > /tmp/seed.log 2>&1
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"
qemu-system-x86_64 -cpu max -m 8G -smp 2 -nographic -no-reboot -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 -s > /tmp/pbc.log 2>&1 &
QPID=$!
for i in $(seq 1 60); do sleep 1; grep -q "database system was shut down\|ready" /tmp/pbc.log 2>/dev/null && break; done
sleep 6
timeout 150 gdb -q -batch -x /tmp/g-tq.py "$KERNEL" > /tmp/gdb-tq.txt 2>&1
kill -9 $QPID 2>/dev/null
grep -vE "add symbol|_addr =|warning|Loadable|manifest|Reading sym|Missing|auto-load| in /b/|MemoryError|of file|do_idle|handle_inc|^540|libsolaris.so 0x|postgres 0x" /tmp/gdb-tq.txt
