#!/bin/bash
# reseed + boot PG with debug logging to see exactly where startup stops.
set -u
bash /tmp/phase-a-seed.sh > /tmp/seed.log 2>&1
tail -1 /tmp/seed.log
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
# -d2 debug logging on the postmaster + startup process
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data -d 2"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/pbdbg.log
qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  > /tmp/pbdbg.log 2>&1 &
QPID=$!
for i in $(seq 1 45); do sleep 1; grep -q "ready to accept" /tmp/pbdbg.log 2>/dev/null && break; done
sleep 4
kill -9 $QPID 2>/dev/null
echo "===== FULL PG DEBUG LOG (after boot banner) ====="
sed -n "/starting PostgreSQL/,\$p" /tmp/pbdbg.log | tail -60
