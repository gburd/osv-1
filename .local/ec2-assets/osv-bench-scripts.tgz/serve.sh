#!/bin/bash
# Start PG (sync=disabled) in background, leave running, print pid.
set -u
bash /tmp/phase-a-seed.sh > /tmp/seed.log 2>&1
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=disabled pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/pbserve.log
nohup qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  > /tmp/pbserve.log 2>&1 &
echo $! > /tmp/qpid
for i in $(seq 1 90); do sleep 1; grep -q "ready to accept" /tmp/pbserve.log 2>/dev/null && { echo "READY at ${i}s (qpid=$(cat /tmp/qpid))"; exit 0; }; done
echo "NOT READY"; tail -5 /tmp/pbserve.log
