#!/bin/bash
# reseed clean pool + boot PG on ZFS-on-NVMe, watch for "ready to accept".
set -u
bash /tmp/phase-a-seed.sh > /tmp/seed.log 2>&1
tail -2 /tmp/seed.log
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/pbrun.log
qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  > /tmp/pbrun.log 2>&1 &
QPID=$!
READY=0
for i in $(seq 1 90); do
  sleep 1
  if grep -q "ready to accept connections" /tmp/pbrun.log 2>/dev/null; then
    echo "== READY at ${i}s =="; READY=1; break
  fi
  if ! kill -0 $QPID 2>/dev/null; then echo "== qemu exited at ${i}s =="; break; fi
done
echo "===== SERIAL TAIL ====="
tail -20 /tmp/pbrun.log
if [ $READY -eq 1 ]; then
  echo "PGPID=$QPID" > /tmp/pg-running.pid
  echo "== leaving qemu running (pid $QPID) for query tests =="
else
  kill -9 $QPID 2>/dev/null
  echo "== NOT READY: killed qemu =="
fi
