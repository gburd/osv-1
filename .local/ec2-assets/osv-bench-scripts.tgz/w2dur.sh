#!/bin/bash
# WALL 2 durability: sync=standard, COMMIT a marker (forces fsync->ZIL on SLOG),
# kill -9 IMMEDIATELY (no checkpoint, no settle) so ONLY the ZIL has it, then
# re-import (ZIL replay) and read it back. HARD timeouts.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
DRIVES="-device virtio-blk-pci,id=blk0,drive=hd0 -drive file=$IMG,if=none,id=hd0,cache=writeback,aio=threads \
 -device virtio-blk-pci,id=blk1,drive=hd1 -drive file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk2,drive=hd2 -drive file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk3,drive=hd3 -drive file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk4,drive=hd4 -drive file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk5,drive=hd5 -drive file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native \
 -device virtio-blk-pci,id=blk6,drive=hd6 -drive file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native"
NET="-netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0"

# --- PHASE 1: sync=standard; commit a marker; kill immediately (no checkpoint) ---
# also disable full_page_writes noise; the point is WAL fsync -> ZIL.
INIT1="/zpool.so import -f -N pgdata ; /zfs.so set sync=standard pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data -c autovacuum=off -c synchronous_commit=on -c fsync=on"
rm -f /tmp/d1.log
timeout 160 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "--rootfs=zfs $INIT1" $DRIVES $NET -s > /tmp/d1.log 2>&1 &
Q1=$!
for i in $(seq 1 150); do sleep 1; grep -q "ready to accept" /tmp/d1.log 2>/dev/null && { echo "P1 READY ${i}s"; break; }; done
grep -q "ready to accept" /tmp/d1.log || { echo P1_NOTREADY; tail -6 /tmp/d1.log|grep -vE "iPXE|SeaBIOS"; kill -9 $Q1; pkill -9 -f qemu-system; exit 1; }
$PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -v ON_ERROR_STOP=1 -c \
  "drop table if exists zild; create table zild(id int primary key, tag text);" 2>&1 | sed 's/^/[ddl] /'
# checkpoint so the CREATE is on disk, THEN commit the marker and DO NOT checkpoint
$PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c "checkpoint;" >/dev/null 2>&1
$PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -v ON_ERROR_STOP=1 -c \
  "begin; insert into zild values (42,'ZIL-REPLAY-MARKER'); commit; select * from zild;" 2>&1 | sed 's/^/[commit] /'
# kill INSTANTLY -- the marker is only in WAL/ZIL, not yet in a ZFS txg checkpoint
kill -9 $Q1 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo "== P1 killed immediately after COMMIT (no checkpoint, no settle) =="
sleep 3

# --- PHASE 2: re-import (ZIL replay) + PG recovery, read marker back ---
INIT2="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data -c autovacuum=off"
rm -f /tmp/d2.log
timeout 160 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "--rootfs=zfs $INIT2" $DRIVES $NET -s > /tmp/d2.log 2>&1 &
Q2=$!
for i in $(seq 1 150); do sleep 1; grep -q "ready to accept" /tmp/d2.log 2>/dev/null && { echo "P2 READY ${i}s"; break; }; done
grep -q "ready to accept" /tmp/d2.log || { echo P2_NOTREADY; tail -8 /tmp/d2.log|grep -vE "iPXE|SeaBIOS"; kill -9 $Q2; pkill -9 -f qemu-system; exit 1; }
echo "-- replay-error check (should be NONE) --"; grep -iE "replay transaction error|SPL PANIC|abd_alloc" /tmp/d2.log | grep -vE "iPXE|SeaBIOS" || echo "  (no ZIL replay error, no panic)"
echo "-- read marker after crash+reimport --"
$PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c "select * from zild;" 2>&1 | sed 's/^/[readback] /'
kill -9 $Q2 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo DONE
