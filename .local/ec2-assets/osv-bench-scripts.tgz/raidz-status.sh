#!/bin/bash
# Import the raidz, print status + errors, run a scrub, mount + check /data.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf
INIT="/zpool.so import -f -N pgdata ; /zpool.so status -v pgdata ; /zpool.so scrub pgdata ; /zpool.so status -v pgdata ; /zfs.so list ; /zpool.so export pgdata"
APPEND="--rootfs=zfs $INIT"
timeout 120 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive file=$IMG,if=none,id=hd0,cache=writeback,aio=threads \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk2,drive=hd2 -drive file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk3,drive=hd3 -drive file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk4,drive=hd4 -drive file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk5,drive=hd5 -drive file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk6,drive=hd6 -drive file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native \
  -netdev user,id=un0 -device virtio-net-pci,netdev=un0 2>&1 | grep -vE "iPXE|SeaBIOS|Press Ctrl|Booting from ROM"
pkill -9 -f qemu-system 2>/dev/null
