#!/bin/bash
# reseed clean pool, then boot+deep-gdb in one shot (clean pool => real hang, not
# the stale-postmaster.pid FATAL).
set -u
bash /tmp/phase-a-seed.sh > /tmp/seed.log 2>&1
tail -3 /tmp/seed.log
bash /tmp/deep-boot.sh
