#!/bin/bash
# Deep dump WITH pg symbols: reproduce hang, osv syms (load PG PIE symbols),
# then osv thread apply all bt. Filter to latch/shm_mq/gather/dsm frames.
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
PGARGS="-c autovacuum=off -c max_parallel_workers=8 -c max_parallel_workers_per_gather=4 -c parallel_setup_cost=0 -c parallel_tuple_cost=0 -c min_parallel_table_scan_size=0"
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=disabled pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data $PGARGS"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/par.log /tmp/parq.log /tmp/par-syms.log
timeout "${PTIMEOUT:-300}" qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive file=$IMG,if=none,id=hd0,cache=writeback,aio=threads \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk2,drive=hd2 -drive file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk3,drive=hd3 -drive file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk4,drive=hd4 -drive file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk5,drive=hd5 -drive file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native \
  -device virtio-blk-pci,id=blk6,drive=hd6 -drive file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 -s > /tmp/par.log 2>&1 &
QPID=$!
for i in $(seq 1 120); do sleep 1; grep -q "ready to accept" /tmp/par.log 2>/dev/null && { echo "READY ${i}s"; break; }; done
grep -q "ready to accept" /tmp/par.log || { echo NOTREADY; tail -6 /tmp/par.log|grep -vE "iPXE|SeaBIOS"; kill -9 $QPID; pkill -9 -f qemu-system; exit 1; }
( $PGBIN/psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -c \
   "set enable_indexonlyscan=off; set enable_indexscan=off; set enable_bitmapscan=off; select count(*) from pgbench_accounts;" > /tmp/parq.log 2>&1; echo "QDONE rc=$?" >> /tmp/parq.log ) &
QSQL=$!
sleep 18
echo "--- parq.log (empty=hung) ---"; cat /tmp/parq.log 2>/dev/null | sed 's/^/[q] /'; echo "(end)"
cd /b/build/last
timeout 150 gdb -q -batch \
  -iex "set auto-load safe-path /" \
  -ex "set pagination off" -ex "set confirm off" \
  -ex "target remote localhost:1234" \
  -ex "osv syms" \
  -ex "osv thread apply all bt" \
  -ex "detach" loader.elf > /tmp/par-syms.log 2>&1
echo "=== frames of interest (latch/gather/shm_mq/dsm/WaitEvent) ==="
grep -nE "Latch|WaitEvent|shm_mq|gather|Gather|dsm_|Parallel|WaitForBackgroundWorker|ConditionVariable|pq_|secure_read|ProcSleep|LWLock|epoll_wait|do_wait|ExecParallel|nodeGather" /tmp/par-syms.log | head -60
echo "=== full bt of first 3 pg18 threads that are NOT epoll postmaster ==="
awk '/^thread .*pg18/{n++} n>=1{print} /^thread 0x/&&!/pg18/{if(n>0)exit}' /tmp/par-syms.log | grep -vE "^\s*$" | head -120
kill -9 $QSQL 2>/dev/null; kill -9 $QPID 2>/dev/null; pkill -9 -f qemu-system 2>/dev/null
echo DONE
