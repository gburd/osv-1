#!/bin/bash
# Phase B under gdb: pause at boot (-S), break on handle_mmap_fault, catch the
# fork-time SIGSEGV, print fault addr + VMA + stack.
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"

qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 \
  -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 \
  -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  -s -S > /tmp/phase-b-gdb-console.log 2>&1 &
QPID=$!
sleep 2

cat > /tmp/gdb.cmds <<'EOF'
set pagination off
set confirm off
target remote localhost:1234
handle SIGSEGV nostop noprint pass
break osv::handle_mmap_fault
continue
printf "\n=== FAULT addr=0x%lx sig=%d ===\n", $rdi, $rsi
bt 25
EOF

timeout 90 gdb -q -batch -x /tmp/gdb.cmds /b/build/last/loader.elf 2>&1 | tail -60
kill -9 $QPID 2>/dev/null
echo "=== console tail ==="
grep -vE 'Adding' /tmp/phase-b-gdb-console.log 2>/dev/null | tail -8
