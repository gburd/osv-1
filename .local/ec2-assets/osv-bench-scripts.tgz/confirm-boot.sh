#!/bin/bash
# Run INSIDE osv-build. Boot combined image (paused via -S), let it run, wait for
# the PG startup hang, then attach gdb and walk threads to confirm candidate (i).
set -u
IMG=/b/build/last/usr.img; KERNEL=/b/build/last/loader.elf; DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"
rm -f /tmp/pbc.log /tmp/gdb-out.txt
qemu-system-x86_64 -cpu max -m 8G -smp 2 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  -s > /tmp/pbc.log 2>&1 &
QPID=$!
# wait until PG logs "shut down" (startup running) or timeout
for i in $(seq 1 60); do
  sleep 1
  if grep -q "database system was shut down\|ready to accept" /tmp/pbc.log 2>/dev/null; then
    echo "== saw startup log at ${i}s =="; break
  fi
done
sleep 6   # let it settle into the hang
echo "===== SERIAL TAIL ====="
tail -25 /tmp/pbc.log
echo "===== GDB THREAD WALK ====="
timeout 200 gdb -q -batch -x /tmp/g-confirm.py "$KERNEL" > /tmp/gdb-out.txt 2>&1
kill -9 $QPID 2>/dev/null
grep -vE "Missing auto-load|auto-load python|warning: File" /tmp/gdb-out.txt
