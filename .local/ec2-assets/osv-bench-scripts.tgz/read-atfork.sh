#!/bin/bash
echo "=== EC2 __osv_run_atfork_* current (lines 300-330) ==="
sed -n '300,330p' /b/libc/pthread.cc
