#!/bin/bash
# Build the RAID-Z pgdata pool on OSv and seed the initdb'd PG cluster into it.
# RUNS INSIDE the osv-build container (has qemu+kvm, /b, /nvme, /dev, python3).
#
# GEOMETRY (spans both storage tiers, ephemeral-NVMe-safe, replicable on Linux):
#   pool "pgdata":
#     raidz1  vblk1 vblk2 vblk3 vblk4     <- 4x 200GB EBS (durable data, 1-disk fault tolerant)
#     log     vblk5                        <- 1x local NVMe as SLOG (fast sync writes; ephemeral OK)
#     cache   vblk6                        <- 1x local NVMe as L2ARC (read cache; ephemeral OK)
# vblk0 = OS image (rootfs=zfs).
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
SRC=/b/.local/pg18/data-init

POOLPROPS="-o ashift=12"
FSPROPS="-O compression=lz4 -O atime=off -O recordsize=8k -O logbias=throughput -O primarycache=all"
CREATE="/zpool.so create -f $POOLPROPS $FSPROPS -m /data pgdata"
CREATE="$CREATE raidz1 /dev/vblk1 /dev/vblk2 /dev/vblk3 /dev/vblk4"
CREATE="$CREATE log /dev/vblk5"
CREATE="$CREATE cache /dev/vblk6"

INIT="$CREATE"
INIT="$INIT ; /zpool.so status pgdata"
INIT="$INIT ; /tools/cpiod.so --prefix /data/ --port 10000"
INIT="$INIT ; /zpool.so export pgdata"
APPEND="--rootfs=zfs $INIT"

echo "== raidz mkpool + seed boot =="
echo "CREATE: $CREATE"
( python3 /tmp/cpio_push.py "$SRC" 127.0.0.1 10000 2>&1 | sed 's/^/[push] /' ) &
PUSH=$!

timeout 420 qemu-system-x86_64 -enable-kvm -cpu host -m 16G -smp 8 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk2,drive=hd2 -drive "file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk3,drive=hd3 -drive "file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk4,drive=hd4 -drive "file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk5,drive=hd5 -drive "file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk6,drive=hd6 -drive "file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native" \
  -netdev "user,id=un0,hostfwd=tcp:127.0.0.1:10000-:10000" -device virtio-net-pci,netdev=un0 \
  2>&1 | tee /tmp/mkpool.log
echo "== qemu exit rc=$? =="
wait $PUSH 2>/dev/null
