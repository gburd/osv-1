#!/bin/bash
# Fix: atfork_handlers vector storage must live on the identity kernel heap, not
# the COW fork arena.  register_atfork() runs on an app thread (musl registers
# PG's handlers), so its std::vector backing store lands in the fork arena and a
# forked child reads a DIVERGENT copy -> __osv_run_atfork_prepare() calls a
# garbage handler pointer -> SIGSEGV.  Same rule/fix as epoll/DSM/app_runtime.
set -e
python3 - <<'PY'
p="/b/libc/pthread.cc"
s=open(p).read()

# 1) add includes (fork_arena + CONF_fork header) after the export.h include.
inc_anchor='#include <osv/export.h>\n'
assert s.count(inc_anchor)==1, ("export.h include", s.count(inc_anchor))
inc_add=inc_anchor+'#include <osv/fork_arena.hh>\n#include <osv/kernel_config_fork.h>\n'
s=s.replace(inc_anchor, inc_add, 1)

# 2) define the ATFORK_KH() scope macro just before __osv_run_atfork_prepare.
kh_anchor='extern "C" void __osv_run_atfork_prepare()\n'
assert s.count(kh_anchor)==1, ("prepare fn", s.count(kh_anchor))
kh_macro=('''// The atfork handler list is populated by register_atfork() on an app thread
// (musl registers PostgreSQL's handlers), so without this its std::vector
// backing store lands in the COW fork arena and a forked child reads a
// DIVERGENT copy -> __osv_run_atfork_prepare() calls a garbage handler pointer
// -> SIGSEGV.  Force the vector's (re)allocations onto the identity kernel heap
// so every address space shares ONE coherent list -- same rule as the epoll /
// DSM-registry / application_runtime fixes.
#if CONF_fork
#define ATFORK_KH() fork_arena::kernel_heap_scope _atfork_kh
#else
#define ATFORK_KH() do {} while (0)
#endif

''')+kh_anchor
s=s.replace(kh_anchor, kh_macro, 1)

# 3) wrap the push_back in register_atfork with the scope.
pb_anchor='    SCOPE_LOCK(atfork_lock);\n    atfork_handlers.push_back({prepare, parent, child});\n    return 0;\n}'
assert s.count(pb_anchor)==1, ("push_back", s.count(pb_anchor))
pb_new='    SCOPE_LOCK(atfork_lock);\n    ATFORK_KH();\n    atfork_handlers.push_back({prepare, parent, child});\n    return 0;\n}'
s=s.replace(pb_anchor, pb_new, 1)

open(p,"w").write(s)
print("patched libc/pthread.cc: atfork_handlers -> identity kernel heap")
PY
echo "=== verify ==="
grep -n "ATFORK_KH\|fork_arena.hh\|kernel_config_fork" /b/libc/pthread.cc
