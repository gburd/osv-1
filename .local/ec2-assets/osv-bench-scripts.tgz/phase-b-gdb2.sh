#!/bin/bash
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"

qemu-system-x86_64 -enable-kvm -cpu host -m 8G -smp 4 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 \
  -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 \
  -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  -s -S > /tmp/pbc.log 2>&1 &
QPID=$!
sleep 2

cat > /tmp/g.cmds <<'EOF'
set pagination off
set confirm off
target remote localhost:1234
break osv::handle_mmap_fault
continue
printf "\n=== FAULT addr=0x%lx sig=%d ===\n", (unsigned long)$rdi, (int)$rsi
bt 22
printf "=== faulting frame (up to vm_fault caller) ===\n"
frame 3
info registers rip rsp rbp
list
EOF

timeout 110 gdb -q -batch -x /tmp/g.cmds /b/build/last/loader.elf 2>&1 | grep -vE "Missing auto-load|auto-load python" | head -80
kill -9 $QPID 2>/dev/null
