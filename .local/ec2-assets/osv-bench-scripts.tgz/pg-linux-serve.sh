#!/bin/bash
# Linux control PG serve: numactl node0, huge_pages toggle via arg on|off.
# usage: pg-linux-serve.sh on|off   (start)   |   pg-linux-serve.sh stop
set -u
PGBIN=$HOME/pg18-linux/install/bin
DATA=/data/pgdata
LOG=/tmp/pg-linux.log
case "${1:-on}" in
  stop)
    $PGBIN/pg_ctl -D "$DATA" stop -m fast 2>&1 | tail -2
    exit 0 ;;
  on)  HP=on  ;;
  off) HP=off ;;
  *) echo "usage: $0 on|off|stop"; exit 1 ;;
esac
# stop any running instance first (clean slate for the cell)
$PGBIN/pg_ctl -D "$DATA" status >/dev/null 2>&1 && $PGBIN/pg_ctl -D "$DATA" stop -m fast >/dev/null 2>&1
sleep 2
# numactl --cpunodebind=0 --membind=0 for the postmaster (NUMA-local, per plan)
numactl --cpunodebind=0 --membind=0 \
  $PGBIN/pg_ctl -D "$DATA" -l "$LOG" -o "-c huge_pages=$HP" -w start 2>&1 | tail -3
sleep 2
echo "=== huge_pages requested: $HP ==="
$PGBIN/psql -h 127.0.0.1 -U postgres -d postgres -tAc "show huge_pages;" 2>&1
$PGBIN/psql -h 127.0.0.1 -U postgres -d postgres -tAc "select 'PG_UP', version();" 2>&1 | head -1
grep -iE "huge|fatal|error" "$LOG" | tail -5
