#!/bin/bash
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
DATADISK=/nvme/pgdata.raw
PGBIN=/b/.local/pg18/install/bin
INIT="/zpool.so import -f -N pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data"
APPEND="--rootfs=zfs $INIT"

qemu-system-x86_64 -cpu max -m 8G -smp 2 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 \
  -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 \
  -drive "file=$DATADISK,if=none,id=hd1,format=raw,cache=writeback,aio=threads" \
  -netdev user,id=un0,hostfwd=tcp:0.0.0.0:5432-:5432 -device virtio-net-pci,netdev=un0 \
  -s -S > /tmp/pbc.log 2>&1 &
QPID=$!
sleep 4

cat > /tmp/g.py <<'PYEOF'
import gdb
gdb.execute("set pagination off")
gdb.execute("set confirm off")
gdb.execute("target remote localhost:1234")
gdb.execute("tbreak osv::handle_mmap_fault")
# synchronous continue until the breakpoint
gdb.execute("continue")
try:
    fa = int(gdb.parse_and_eval("$rdi"))
    print("FAULTADDR=0x%x" % fa)
except Exception as e:
    print("no rdi", e)
gdb.execute("frame 6")
for cmd in ["print it", "print atfork_handlers",
            "print (void*)it->prepare",
            "info symbol (unsigned long)it->prepare"]:
    try:
        print(">>", cmd); gdb.execute(cmd)
    except Exception as e:
        print("err", cmd, e)
# inspect the VMA at the fault address
try:
    fa = int(gdb.parse_and_eval("$rdi"))
    print(">> find_intersecting_vma(0x%x)" % fa)
    gdb.execute("print mmu::find_intersecting_vma(0x%x)" % fa)
except Exception as e:
    print("vma err", e)
PYEOF

timeout 280 gdb -q -batch -x /tmp/g.py /b/build/last/loader.elf > /tmp/gdb-out.txt 2>&1
kill -9 $QPID 2>/dev/null
echo "===== GDB ====="
grep -vE "Missing auto-load|auto-load python" /tmp/gdb-out.txt | head -50
