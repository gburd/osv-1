#!/bin/bash
# Firecracker tap networking for the OSv-PG guest, cross-instance reachable.
# Mirrors the KVM setup-tap-net.sh but for FC's tap model.
#   external EC2 (same subnet) --> 172.31.12.108:5432 (host ENI enp125s0)
#       --iptables DNAT-->          192.168.100.2:5432 (OSv guest on fc_tap0)
set -eu
HOST_ENI=enp125s0
TAP=fc_tap0
TAP_HOST_IP=192.168.100.1
GUEST_IP=192.168.100.2
PGPORT=5432

if ! ip link show "$TAP" >/dev/null 2>&1; then
  sudo ip tuntap add dev "$TAP" mode tap
  sudo ip addr add "$TAP_HOST_IP/24" dev "$TAP"
fi
sudo ip link set "$TAP" up
sudo sysctl -w net.ipv4.ip_forward=1 >/dev/null

# DNAT host ENI:5432 -> guest ; MASQUERADE guest egress ; allow forwarding.
sudo iptables -t nat -D PREROUTING -i "$HOST_ENI" -p tcp --dport "$PGPORT" -j DNAT --to-destination "$GUEST_IP:$PGPORT" 2>/dev/null || true
sudo iptables -t nat -A PREROUTING -i "$HOST_ENI" -p tcp --dport "$PGPORT" -j DNAT --to-destination "$GUEST_IP:$PGPORT"
sudo iptables -t nat -D POSTROUTING -s "$GUEST_IP/32" -o "$HOST_ENI" -j MASQUERADE 2>/dev/null || true
sudo iptables -t nat -A POSTROUTING -s "$GUEST_IP/32" -o "$HOST_ENI" -j MASQUERADE
sudo iptables -D FORWARD -i "$HOST_ENI" -o "$TAP" -p tcp --dport "$PGPORT" -j ACCEPT 2>/dev/null || true
sudo iptables -A FORWARD -i "$HOST_ENI" -o "$TAP" -p tcp --dport "$PGPORT" -j ACCEPT
sudo iptables -D FORWARD -i "$TAP" -o "$HOST_ENI" -j ACCEPT 2>/dev/null || true
sudo iptables -A FORWARD -i "$TAP" -o "$HOST_ENI" -j ACCEPT

echo "fc_tap0 up: host=$TAP_HOST_IP guest=$GUEST_IP ; DNAT :$PGPORT -> $GUEST_IP:$PGPORT"
ip -4 addr show "$TAP" | grep inet
