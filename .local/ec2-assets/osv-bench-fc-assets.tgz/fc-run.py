#!/usr/bin/env python3
# Multi-drive Firecracker launcher for OSv-PG on a RAID-Z.
# firecracker.py ships only single-drive + v0.23; FC v1.7 config-file supports
# N drives. We add the OS image (rootfs) + the 6 raidz member block devices as
# virtio-blk, and a tap NIC (fc_tap0) so the guest PG is cross-instance reachable.
#
# Guest vblk order = drive declaration order:
#   vblk0 = usr.raw (rootfs=zfs)
#   vblk1..vblk4 = 4x EBS  -> raidz1
#   vblk5 = 1x NVMe -> log (SLOG)
#   vblk6 = 1x NVMe -> cache (L2ARC)
#
# Usage: fc-run.py --append "<osv cmdline>" [--vcpus N] [--mem 16384] [--net]
#                  [--members "dev1,dev2,..."]  (defaults to the 6 raidz members)
import argparse, json, os, signal, subprocess, sys, tempfile, time

FC = "/usr/local/bin/firecracker"
OSV = "/home/ec2-user/osv/build/last"
KERNEL = OSV + "/loader-stripped.elf"
ROOTFS = OSV + "/usr.raw"
DEFAULT_MEMBERS = ["/dev/nvme5n1","/dev/nvme6n1","/dev/nvme7n1","/dev/nvme8n1",  # 4 EBS -> raidz1
                   "/dev/nvme0n1","/dev/nvme3n1"]                                 # 2 NVMe -> log,cache
GUEST_IP="192.168.100.2"; GW="192.168.100.1"; TAP="fc_tap0"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--append", required=True)
    ap.add_argument("--vcpus", type=int, default=8)
    ap.add_argument("--mem", type=int, default=16384)   # MiB
    ap.add_argument("--net", action="store_true")
    ap.add_argument("--members", default=",".join(DEFAULT_MEMBERS))
    ap.add_argument("--socket", default="/tmp/fc.sock")
    a = ap.parse_args()

    cmdline = a.append
    if a.net:
        cmdline = "--ip=eth0,%s,255.255.255.0 --defaultgw=%s %s" % (GUEST_IP, GW, cmdline)
    cmdline = "--nopci " + cmdline

    drives = [{"drive_id":"rootfs","path_on_host":ROOTFS,"is_root_device":False,"is_read_only":False}]
    members = [m for m in a.members.split(",") if m]
    for i,m in enumerate(members, start=1):
        drives.append({"drive_id":"blk%d"%i,"path_on_host":m,"is_root_device":False,"is_read_only":False})

    cfg = {
        "boot-source": {"kernel_image_path": KERNEL, "boot_args": cmdline},
        "drives": drives,
        "machine-config": {"vcpu_count": a.vcpus, "mem_size_mib": a.mem, "smt": False},
    }
    if a.net:
        cfg["network-interfaces"] = [{"iface_id":"eth0","host_dev_name":TAP,"guest_mac":"52:54:00:12:34:56"}]

    cf = tempfile.NamedTemporaryFile(delete=False, suffix=".json", mode="w")
    json.dump(cfg, cf, indent=2); cf.flush(); cf.close()
    print("== FC config %s ==" % cf.name, flush=True)
    print(json.dumps(cfg, indent=2), flush=True)
    print("== boot_args: %s ==" % cmdline, flush=True)

    if os.path.exists(a.socket): os.unlink(a.socket)
    p = subprocess.Popen([FC, "--no-api", "--config-file", cf.name],
                         stdout=sys.stdout, stderr=subprocess.STDOUT)
    try:
        p.wait()
    except KeyboardInterrupt:
        os.kill(p.pid, signal.SIGINT)
        p.wait()
    finally:
        os.unlink(cf.name)

if __name__ == "__main__":
    main()
