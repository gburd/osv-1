#!/bin/bash
# Serve the SAME OSv image + SAME raidz under qemu/KVM (PCI virtio), to isolate
# whether the fork catalog-read-zero bug is Firecracker-specific or OSv-common.
# Runs INSIDE the osv-kvm container (--network host, /dev/kvm, /b=~/osv).
set -u
IMG=/b/build/last/usr.img
KERNEL=/b/build/last/loader.elf
PGBIN=/b/.local/pg18/install/bin
GUEST=192.168.100.2 ; GW=192.168.100.1
PGC="-c shared_buffers=8GB -c effective_cache_size=24GB -c work_mem=32MB -c max_connections=256 -c max_wal_size=16GB -c checkpoint_timeout=15min -c synchronous_commit=on -c max_parallel_workers=0 -c max_parallel_workers_per_gather=0 -c listen_addresses=* -c port=5432 -c huge_pages=off"
INIT="/zpool.so import -f -N pgdata ; /zfs.so set sync=disabled pgdata ; /zfs.so mount pgdata ; $PGBIN/postgres -D /data $PGC"
APPEND="--rootfs=zfs --ip=eth0,$GUEST,255.255.255.0 --defaultgw=$GW $INIT"
rm -f /tmp/kvm-serve.log
nohup qemu-system-x86_64 -enable-kvm -cpu host -m 40G -smp 16 -nographic -no-reboot \
  -kernel "$KERNEL" -append "$APPEND" \
  -device virtio-blk-pci,id=blk0,drive=hd0 -drive "file=$IMG,if=none,id=hd0,cache=writeback,aio=threads" \
  -device virtio-blk-pci,id=blk1,drive=hd1 -drive "file=/dev/nvme5n1,if=none,id=hd1,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk2,drive=hd2 -drive "file=/dev/nvme6n1,if=none,id=hd2,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk3,drive=hd3 -drive "file=/dev/nvme7n1,if=none,id=hd3,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk4,drive=hd4 -drive "file=/dev/nvme8n1,if=none,id=hd4,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk5,drive=hd5 -drive "file=/dev/nvme0n1,if=none,id=hd5,format=raw,cache=none,aio=native" \
  -device virtio-blk-pci,id=blk6,drive=hd6 -drive "file=/dev/nvme3n1,if=none,id=hd6,format=raw,cache=none,aio=native" \
  -netdev tap,id=un0,ifname=fc_tap0,script=no,downscript=no \
  -device virtio-net-pci,netdev=un0,mac=52:54:00:12:34:56 \
  > /tmp/kvm-serve.log 2>&1 &
echo $! > /tmp/kvm.pid
for i in $(seq 1 90); do sleep 1; grep -q "ready to accept" /tmp/kvm-serve.log 2>/dev/null && { echo "KVM READY at ${i}s"; break; }; grep -qi "abort\|panic\|Assertion" /tmp/kvm-serve.log && { echo KVM_CRASH; tail -15 /tmp/kvm-serve.log; break; }; done
grep -q "ready to accept" /tmp/kvm-serve.log || { echo KVM_NOT_READY; tail -20 /tmp/kvm-serve.log; }
