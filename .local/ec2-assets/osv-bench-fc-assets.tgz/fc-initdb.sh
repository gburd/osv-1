#!/bin/bash
# FRESH initdb DIRECTLY on this box's raidz, IN-GUEST under Firecracker.
# No host cluster copy, no cpio -- the cluster is created by the in-guest initdb
# binary onto the ZFS /data. This is the clean (a)seed-artifact vs (b)real-read-bug
# discriminator: if a fresh in-guest cluster reads pg_authid clean from a NEW
# connection, the earlier corruption was a seed/accumulated artifact.
set -u
PGBIN=/b/.local/pg18/install/bin
GUEST=192.168.100.2

# Step 1: create an EMPTY pool (same geometry/props), then initdb onto /data,
# configure conf, and leave the pool exported clean.
POOLPROPS="-o ashift=12"
FSPROPS="-O compression=lz4 -O atime=off -O recordsize=8k -O logbias=throughput -O primarycache=all"
CREATE="/zpool.so create -f $POOLPROPS $FSPROPS -m /data pgdata raidz1 /dev/vblk1 /dev/vblk2 /dev/vblk3 /dev/vblk4 log /dev/vblk5 cache /dev/vblk6"
# initdb (C locale, trust auth, TCP). Then append benchmark-safe conf lines.
INITDB="$PGBIN/initdb -D /data -U postgres --no-locale -E UTF8 -A trust"
CONF="echo \"listen_addresses='*'\" >> /data/postgresql.conf ; echo \"port=5432\" >> /data/postgresql.conf ; echo \"unix_socket_directories=''\" >> /data/postgresql.conf ; echo \"fsync=on\" >> /data/postgresql.conf"
HBA="echo 'host all all 0.0.0.0/0 trust' >> /data/pg_hba.conf"
INIT="$CREATE ; /zfs.so set sync=disabled pgdata ; $INITDB ; $CONF ; $HBA ; /zpool.so export pgdata"
echo "== FC fresh-initdb-on-raidz =="
rm -f /tmp/fc-initdb.log
sudo timeout 180 python3 /tmp/fc-run.py --append "--rootfs=zfs $INIT" --vcpus 8 --mem 16384 > /tmp/fc-initdb.log 2>&1
echo "== initdb boot exit rc=$? =="
sudo pkill -9 firecracker 2>/dev/null
grep -iE "initdb|success|ok|error|abort|assert|Powering|exit_code|WARNING|FATAL|Success" /tmp/fc-initdb.log | tail -30
