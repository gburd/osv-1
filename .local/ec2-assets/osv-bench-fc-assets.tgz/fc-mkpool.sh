#!/bin/bash
# Build the RAID-Z pgdata pool under FIRECRACKER + seed the initdb'd cluster.
# Same geometry as the KVM raidz-mkpool.sh:
#   pool "pgdata": raidz1 vblk1..vblk4 (4x EBS) ; log vblk5 (NVMe SLOG) ; cache vblk6 (NVMe L2ARC)
# vblk0 = OS image (rootfs=zfs). Seed pushed via cpiod over the tap net.
set -u
SRC=/home/ec2-user/osv/.local/pg18/data-init
GUEST=192.168.100.2

POOLPROPS="-o ashift=12"
FSPROPS="-O compression=lz4 -O atime=off -O recordsize=8k -O logbias=throughput -O primarycache=all"
CREATE="/zpool.so create -f $POOLPROPS $FSPROPS -m /data pgdata"
CREATE="$CREATE raidz1 /dev/vblk1 /dev/vblk2 /dev/vblk3 /dev/vblk4"
CREATE="$CREATE log /dev/vblk5"
CREATE="$CREATE cache /dev/vblk6"
INIT="$CREATE ; /zpool.so status pgdata ; /tools/cpiod.so --prefix /data/ --port 10000 ; /zpool.so export pgdata"

echo "== FC raidz mkpool + seed =="
echo "CREATE: $CREATE"
# start the guest under FC (net on), background, then push the cluster.
sudo timeout 300 python3 /tmp/fc-run.py --append "--rootfs=zfs $INIT" --vcpus 8 --mem 16384 --net > /tmp/fc-mkpool.log 2>&1 &
FCPID=$!
# wait for cpiod's "Waiting for connection from host..." ready line in the log.
for i in $(seq 1 90); do
  sleep 2
  grep -q "Waiting for connection from host" /tmp/fc-mkpool.log && { echo "cpiod ready at ${i}x2s"; break; }
  grep -qi "assert\|abort\|panic" /tmp/fc-mkpool.log && { echo "GUEST CRASH during pool create"; break; }
done
sleep 1
echo "== pushing cluster =="
python3 /tmp/cpio_push.py "$SRC" "$GUEST" 10000 2>&1 | sed 's/^/[push] /'
echo "== push rc=$? ; waiting for guest export+exit =="
wait $FCPID 2>/dev/null
echo "== FC exit =="
sudo pkill -9 firecracker 2>/dev/null
tail -40 /tmp/fc-mkpool.log
